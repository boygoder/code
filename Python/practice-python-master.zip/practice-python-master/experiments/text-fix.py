import ftfy


def main():
    print(ftfy.fix_encoding('ì£¼ë¬¸í•˜ë‹¤ - to intent for?'))


if __name__ == '__main__':
    main()
