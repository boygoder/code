# Practice Python

Part of my daily plan for studying Python.

**Important**

This code may be terrible and buggy. Use at your own risk.